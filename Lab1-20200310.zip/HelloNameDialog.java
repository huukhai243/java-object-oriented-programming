//Example 3 : HelloNameDialog.java
import javax.swing.JOptionPane;
public class HelloNamedialog{
  public static void main( String[] args){
 string result;
     result=JOptionPane.showMessageDialog("Please enter your name:");
     JOptionPane.showmessageDialog(null,"Hi"+result+"!");
     System.exit(0);
   }
}
