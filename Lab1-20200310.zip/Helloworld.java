//Example 1: HelloWorld.java
//Text-printing program
public class Helloworld{

public static void main(String arg[]){
     System.out.println("Xin chao \n cac ban!");
     System.out.println("Hello \t world");

}// end of method main
}
