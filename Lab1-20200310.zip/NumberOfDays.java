import java.util.Scanner;

public class NumberOfDays {
    public static void main(String[] args) {
        int month = -1, year = -1;
        Scanner keyboard = new Scanner(System.in);
        do {
            System.out.println("Enter month?");
            String strMonth = keyboard.nextLine();
            if (strMonth.equalsIgnoreCase("January") || strMonth.equalsIgnoreCase("Jan") || strMonth.equalsIgnoreCase("Jan.") || strMonth.equalsIgnoreCase("1"))
                month = 1;
            else if (strMonth.equalsIgnoreCase("February") || strMonth.equalsIgnoreCase("Feb") || strMonth.equalsIgnoreCase("Feb.") || strMonth.equalsIgnoreCase("2"))
                month = 2;
            else if (strMonth.equalsIgnoreCase("March") || strMonth.equalsIgnoreCase("Mar") || strMonth.equalsIgnoreCase("Mar.") || strMonth.equalsIgnoreCase("3"))
                month = 3;
            else if (strMonth.equalsIgnoreCase("April") || strMonth.equalsIgnoreCase("Apr") || strMonth.equalsIgnoreCase("Apr.") || strMonth.equalsIgnoreCase("4"))
                month = 4;
            else if (strMonth.equalsIgnoreCase("May") || strMonth.equalsIgnoreCase("5"))
                month = 5;
            else if (strMonth.equalsIgnoreCase("June") || strMonth.equalsIgnoreCase("Jun") || strMonth.equalsIgnoreCase("6"))
                month = 6;
            else if (strMonth.equalsIgnoreCase("July") || strMonth.equalsIgnoreCase("Jul")  || strMonth.equalsIgnoreCase("7"))
                month = 7;
            else if (strMonth.equalsIgnoreCase("August") || strMonth.equalsIgnoreCase("Aug") || strMonth.equalsIgnoreCase("Aug.") || strMonth.equalsIgnoreCase("8"))
                month = 8;
            else if (strMonth.equalsIgnoreCase("September") || strMonth.equalsIgnoreCase("Sep") || strMonth.equalsIgnoreCase("Sept.") || strMonth.equalsIgnoreCase("9"))
                month = 9;
            else if (strMonth.equalsIgnoreCase("October") || strMonth.equalsIgnoreCase("Oct") || strMonth.equalsIgnoreCase("Oct.") || strMonth.equalsIgnoreCase("10"))
                month = 10;
            else if (strMonth.equalsIgnoreCase("November") || strMonth.equalsIgnoreCase("Nov") || strMonth.equalsIgnoreCase("Nov.") || strMonth.equalsIgnoreCase("11"))
                month = 11;
            else if (strMonth.equalsIgnoreCase("December") || strMonth.equalsIgnoreCase("Dec") || strMonth.equalsIgnoreCase("Dec.") || strMonth.equalsIgnoreCase("12"))
                month = 12;
        } while (month < 1);
        do {
            System.out.println("Enter year?");
            year = keyboard.nextInt();
        } while (year < 0);
        int daysInMonth = month != 2 ?
                31 - (((month - 1) % 7) % 2) :
                28 + (year % 4 == 0 ? 1 : 0) - (year % 100 == 0 ? 1 : 0) + (year % 400 == 0 ? 1 : 0);
        System.out.println("Number of days in month is " + daysInMonth);
    }
}
